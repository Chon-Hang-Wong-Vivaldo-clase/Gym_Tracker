import 'package:flutter/material.dart';

class MonthInsights extends StatefulWidget {
  const MonthInsights({super.key});

  @override
  State<MonthInsights> createState() => _MonthInsightsState();
}

class _MonthInsightsState extends State<MonthInsights> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
