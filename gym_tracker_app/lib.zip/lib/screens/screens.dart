export 'package:gym_tracker_app/screens/home_screen.dart';
export 'package:gym_tracker_app/screens/login_screen.dart';
export 'package:gym_tracker_app/screens/register_screen.dart';
export 'package:gym_tracker_app/screens/profile_screen.dart';
export 'package:gym_tracker_app/screens/social_screen.dart';
